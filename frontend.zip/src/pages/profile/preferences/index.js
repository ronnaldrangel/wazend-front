import React from 'react';

import ProfileLayout from '../../../layout/ProfileLayout';


export default function General() {

    return (
        <>
        <ProfileLayout>
            <p>Preferencias</p>
        </ProfileLayout>
        </>
    );
};

